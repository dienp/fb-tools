/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var dirName="poofp";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.cant_be_null="Access token can not be null.";
messages.no_response="No response received from the server.";
messages.make_sure="Make sure you have entered valid access token with \"manage_pages\" and \"publish_actions\" permissions, also check that you are a manager of at least one Facebook page.";
messages.please_wait="Please wait for few seconds and your message will be shared on all pages.";
messages.posted="Posted on page.";
messages.invalid_token='Invalid access token.';
messages.invalid_message='Invalid message.'
messages.invalid_url='Invalid URL.';
