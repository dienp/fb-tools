/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Message All Facebook Friends";
var dirName="maff";
var dirName="maff";
var dirName="maff";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.unsafe_content="The content you're trying to share includes a link that our security systems detected to be unsafe.";
messages.success="Messages sent successfully.";
messages.enter_valid_delay="Please enter a valid delay time.";
messages.invalid_sticker= "Sticker ID is invalid.";
messages.cant_be_null= "Message or sticker ID can't be null.";
messages.not_complete= "Friend list extraction is not complete. Please wait until friend list extraction is complete.";
messages.should_be_less_than= "Starting friend number should be less than ending friend number.";
messages.delay_msg= "Delay time should be greater than zero.";
messages.ending_msg= "Ending friend number should be greater than one.";
messages.starting_msg= "Starting friend number should be greater than zero.";
messages.invalid_msg= "Invalid message.";
messages.invalid_delay_msg='Invalid delay.';
messages.invalid_starting_num='Invalid starting number.';
messages.invalid_ending_num='Invalid ending number.';
messages.starting_and_ending="Starting number and ending number can't be equal.";
messages.start_and_end="Starting number can't be greater than ending number.";
