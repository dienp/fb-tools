/*
Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
See license file for more information
Contact developers at mr.dinesh.bhosale@gmail.com
*/
var dirName="caafb";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.clicked="Add friend button is clicked.";
messages.unable_to_find='Unable to find add friend buttons.';
messages.clicked='All add friend buttons are clicked.';
messages.clicked2=messages.clicked;
