/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Join Multiple Groups Using Group IDs";
var dirName="jmugids";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.request_sent="All requests to join groups are sent.";
messages.invalid_input='Invalid input.';
messages.invalid_delay='Delay time is invalid.';
messages.unable_to_get_gid='Unable to get group IDs.';
messages.invalid_gid="Group IDs are invalid.";
messages.req_sent="Request to join group is sent.";
