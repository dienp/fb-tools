/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Invite Your Friends To Like Your Page";
var dirName="iyftlyp";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.incorrect_page_id="You entered incorrect page id.";
messages.invalid_delay="Please enter valid delay time.";
messages.not_complete="Friend list extraction is not complete, Please wait until friend list extraction is complete. Also make sure that you have at least one friend in your Facebook account.";
messages.delay_time="Delay time is now set to one second.";
messages.page_invitation_complete="Page invitation process is completed.";
messages.invalid_delay_time='Delay time is invalid, Please enter valid delay time.';
messages.added_as_member="Friend is added as a group member.";
