/*
Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
See license file for more information
Contact developers at mr.dinesh.bhosale@gmail.com
*/
//any tool that includes this file gets access to friend_list stored in local storage
//set local names
if (user_id) {
	var dates1 = new Date();
	var yur = dates1.getFullYear();
	var dt = dates1.getDate();
	var mon = dates1.getMonth();
	var localname_friend_ids = "fst_friendid_" + user_id + dt + '_' + mon + '_' + yur + "_permanent";
	var localname_friend_ids_temp = "fst_friendid_" + user_id + dt + '_' + mon + '_' + yur + "_temp";
}
//if friendlist toast num divided by 10==0 . 
var friendlist_toast_num = 9;
var friend_id_extractor_name = "Friend ID extraction tool";
function update_ending_friend_number_all(uniq_name_length) {
	$(".fst789_ending_friend_number").val(uniq_name_length);
}
function resetFriendlist() {
	chrome.storage.local.set(JSON.parse("{\"" + localname_friend_ids + "\":\"" + "\"}"), function() {
		console.log(friend_id_extractor_name + ":localname_friend_ids_temp is reset");
	});
}
function resetLocalnameFriendIdsTemp() {
	//reset localname_friend_ids_temp
	chrome.storage.local.set(JSON.parse("{\"" + localname_friend_ids_temp + "\":\"" + "\"}"), function() {
		console.log(friend_id_extractor_name + ":localname_friend_ids_temp is reset");
	});
}
var friendid_array_new = [];
function friendlist_generator() {
	console.log("localname_friend_ids=" + localname_friend_ids + "|localname_friend_ids_temp=" + localname_friend_ids_temp);
	//reset localname_friend_ids_temp
	chrome.storage.local.set(JSON.parse("{\"" + localname_friend_ids_temp + "\":\"" + "\"}"), function() {
		console.log(friend_id_extractor_name + ":localname_friend_ids_temp is reset");
	});
	function loopingoooo(startindex) {
		var message = 'Please wait, extracting friend list';
		friendlist_toast_num++;
		if (friendlist_toast_num % 10 == 0) {
			toastr.info(message);
		}
		var friendid_array = [];
		//var friendid_array_new = [];
		startindex++;
		friendlist_get = new XMLHttpRequest();
		parser = new DOMParser();
		friendlist_get.open("GET", "https://mbasic.facebook.com/friends/center/friends/?ppk=" + startindex, true);
		friendlist_get.onreadystatechange = function() {
			if (friendlist_get.readyState == 4) {
			var json = JSON.parse(unescape(friendlist_get.responseText.match(/\[{.+}\]/g)));
			console.log('json', json);
			
				if (friendlist_get.responseText.match(/uid=\d+/g) && startindex <= 500) {
					var doc = parser.parseFromString(friendlist_get.responseText, "text/html");
					var docElm = doc.getElementsByClassName("bq");
					var name_uid = "";
					for (j = 0; j<docElm.length;j++) {
					  //console.log(docElm[j].text + " - " + docElm[j].search.match(/uid=\d+/g).toString());
					  name_uid += docElm[j].text + ":" + docElm[j].search.match(/uid=\d+/g).toString().replace("uid=", "") + ",";
					  
					}
					friendid_array_new = name_uid;
					/*------------------OLD------------------------*/
					friendid_array = friendlist_get.responseText.match(/uid=\d+/g);
					friendid_array = friendid_array.toString() + ",";
					for (; friendid_array.match("uid=");) {
						friendid_array = friendid_array.replace("uid=", "");
					}
					friendid_array = friendid_array_new;
					/*------------------OLD------------------------*/
					
					//check if localname_friend_ids temp is set or not
					//if it is set then append
					//if it is not set then don't append
					chrome.storage.local.get(localname_friend_ids_temp, function(e) {
						//console.log(friend_id_extractor_name + ":inside first local storage function");
						//console.log("localname_friend_ids=" + localname_friend_ids + "|localname_friend_ids_temp=" + localname_friend_ids_temp);
						if (e) {
							if (e[localname_friend_ids_temp]) {
								//console.log(friend_id_extractor_name+":e[localname_friend_ids_temp]=");
								//console.log(e[localname_friend_ids_temp]);
								//append
								chrome.storage.local.get(localname_friend_ids_temp, function(e) {
									if (e) {
										if (e[localname_friend_ids_temp]) {
											chrome.storage.local.set(JSON.parse("{\"" + localname_friend_ids_temp + "\":\"" + e[localname_friend_ids_temp] + friendid_array + "\"}"), function() {
												//restart process
												loopingoooo(startindex);
											});
										}
									}
								});
							} else {
								//set
								chrome.storage.local.set(JSON.parse("{\"" + localname_friend_ids_temp + "\":\"" + friendid_array + "\"}"), function() {
									//restart process
									console.log(friend_id_extractor_name+":localname_friend_ids_temp is set");
									loopingoooo(startindex);
								});
							}
						} else {
							//set
							chrome.storage.local.set(JSON.parse("{\"" + localname_friend_ids_temp + "\":\"" + friendid_array + "\"}"), function() {
								//restart process
								console.log(friend_id_extractor_name+":localname_friend_ids_temp is set");
								loopingoooo(startindex);
							});
						}
					});
				} else {
					if (startindex == 0) {
						//unable to find any friend ids at all, so use second method for getting friend ids
						resetFriendlist();
						friendlist_generate2_start();
					} else {
						chrome.storage.local.get(localname_friend_ids_temp, function(e) {
							if (e) {
								if (e[localname_friend_ids_temp]) {
									//remove duplicates from friend id array
									var names = e[localname_friend_ids_temp].split(",");
									var uniqueNames = [];
									$.each(names, function(i, el) {
										if ($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
									});
									var uniq_name_length = uniqueNames.length;
									update_ending_friend_number_all(uniq_name_length);
									uniqueNames = uniqueNames.toString();
									chrome.storage.local.set(JSON.parse("{\"" + localname_friend_ids + "\":\"" + uniqueNames + "\"}"), function() {
										console.log(e[localname_friend_ids_temp]);
										console.log(friend_id_extractor_name + ":localname_friend_ids is set");
										//reset localname_friend_ids temp
										chrome.storage.local.set(JSON.parse("{\"" + localname_friend_ids_temp + "\":\"" + "\"}"), function() {
											console.log(friend_id_extractor_name+":localname_friend_ids_temp is reset");
										});
									});
									alert("Friend list extraction completed");
									toastr.info("Friend list extraction completed");
								}
							}
						});
					}
				}
			}
		}
		
		friendlist_get.send();
	}
	loopingoooo(-1);
}
function friendlist_generate_start_DD() {
	var user_id = '';
	if (document.cookie.match(/c_user=(\d+)/)) {
		if (document.cookie.match(/c_user=(\d+)/)[1]) {
			user_id = document.cookie.match(document.cookie.match(/c_user=(\d+)/)[1])
		};
	};
	var xmlhttp = new XMLHttpRequest;
	xmlhttp.open("GET", "/ajax/typeahead/first_degree.php?__a=1&filter[0]=user&lazy=0&viewer=" + user_id + "&token=v7&stale_ok=0&options[0]=friends_only&options[1]=nm", true);
	xmlhttp.onreadystatechange = function () {
		if (xmlhttp.readyState == 4) {
			var json = JSON.parse(unescape(xmlhttp.responseText.match(/\[{.+}\]/g)));
			console.log('json', json);
			var JSONData = [];
			json.forEach(function (el, i) {
				var object = `{"UID":"id=${el.uid}","Full name":"${el.text}","Profile page":"https://www.fb.com${el.path}"}`;
				JSONData.push(JSON.parse(object));
			});
			var ReportTitle = "Friend_List";
			var ShowLabel = true;
			var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
			var CSV = "";
			CSV += ReportTitle + escape('\r\n\n');
			if (ShowLabel) {
				var row = "";
				for (var index in arrData[0]) {
					row += index + ',';
				}
				row = row.slice(0, -1);
				CSV += row + escape('\r\n');
			}
			for (var i = 0; i < arrData.length; i++) {
				var row = "";
				for (var index in arrData[i]) {
					row += '' + unescape(arrData[i][index]) + ',';
				}
				row.slice(0, row.length - 1);
				CSV += row + escape('\r\n');
			}
			if (CSV == '') {
				alert("Invalid data");
				return;
			}
			var fileName = "";
			fileName += ReportTitle.replace(/ /g, "_");
			var uri = 'data:text/csv;charset=utf-8,﻿' + CSV;
			var link = document.createElement("a");
			link.href = uri;
			link.style = "visibility:hidden";
			link.download = fileName + ".csv";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		};
	};
	xmlhttp.send();
}
//starting function
function friendlist_generate_start() {
chrome.storage.local.clear(function() {
    var error = chrome.runtime.lastError;
    if (error) {
        console.error(error);
    }
});
	chrome.storage.local.get(localname_friend_ids, function(e) {
		if (e) {
			if (e[localname_friend_ids] != "" && e[localname_friend_ids]) {
				console.log(friend_id_extractor_name + ":localname_friend_ids is already set");
			} else {
				friendlist_generator();
			}
		} else {
			friendlist_generator();
		}
	});
	console.log("friendid_array_new = "+ friendid_array_new);
}
//start friendlist generator 1
//friendlist_generate_start();
//if first method of generating friend list fails, then use second method
function friendlist_generator_2() {
	var xmlhttp = new XMLHttpRequest;
	xmlhttp.open("GET", "/ajax/typeahead/first_degree.php?__a=1&filter[0]=user&lazy=0&viewer=" + user_id + "&token=v7&stale_ok=0&options[0]=friends_only&options[1]=nm", true);
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4) {
			var friendidcollect = "";
			for (a = 0; a != "stop"; a++) {
				if (xmlhttp.responseText.match(/profile.php\?id=\d+/g)[a] == null) {
					a = "stop";
					break;
				};
				if (xmlhttp.responseText.match(/profile.php\?id=\d+/g)[a].replace("profile.php\?id=", "") != null || xmlhttp.responseText.match(/profile.php\?id=\d+/g)[a + 1].replace("profile.php\?id=", "") != null || xmlhttp.responseText.match(/profile.php\?id=\d+/g)[a + 2].replace("profile.php\?id=", "") != null) {
					var newId=xmlhttp.responseText.match(/profile.php\?id=\d+/g)[a].replace("profile.php\?id=", "") + "|";
					if(!newId.match(user_id)){
						friendidcollect += newId;
						console.log("newId = "+newId)
					}
				} else {
					a = "stop";
				};
			};
			console.log("friendidcollect=" + friendidcollect);
			console.log("friendidcollectlength=" + friendidcollect.split("|").length)
			var friendidarray = friendidcollect.split("|");
			var totalfriendnum = friendidcollect.split("|").length;
			console.log(friendidarray);
			chrome.storage.local.set(JSON.parse("{\"" + localname_friend_ids + "\":\"" + friendidarray.toString() + "\"}"), function() {
				console.log(friend_id_extractor_name + ":localname_friend_ids is set");
				//reset localname_friend_ids temp
				chrome.storage.local.set(JSON.parse("{\"" + localname_friend_ids_temp + "\":\"" + "\"}"), function() {
					console.log(friend_id_extractor_name+":localname_friend_ids_temp is reset");
				});
			});
			//alert("Friend list extraction completed");
			toastr.success("Friend list extraction completed");
		};
	}
	xmlhttp.send();
}
function friendlist_generate2_start() {
	chrome.storage.local.get(localname_friend_ids, function(e) {
		if (e) {
			if (e[localname_friend_ids] != "" && e[localname_friend_ids]) {
				console.log(friend_id_extractor_name + ":localname_friend_ids is already set");
			} else {
				friendlist_generator_2();
			}
		} else {
			friendlist_generator_2();
		}
	});
}
//for starting friendlist generator
//friendlist_generate_start()
