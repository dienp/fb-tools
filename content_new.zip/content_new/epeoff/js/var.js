/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Extract Emails Of Facebook Friends";
var dirName = "epeoff";
var targetFrameId = 'fstFrameDiv';
var targetDivId = 'fstParentDiv';
var messages={};
messages.not_complete="Friend list extraction is not complete. Please wait until friend list extraction is completed.";
messages.unable_to_detect="Unable to detect friend IDs.";
messages.completed="Email extraction completed.";
messages.extracting_emails='Please wait, extracting emails.';
messages.started="Email extraction started.";
