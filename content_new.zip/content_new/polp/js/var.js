/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Invite Your Friends To Like Your Page";
var dirName="polp";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={}
messages.enter_valid_url="Please enter valid URL.";
messages.please_wait="Please wait until user likes are extracted.";
messages.invalid_delay="Delay time is not a valid number.";
messages.invalid_message="Invalid message.";
messages.invalid_tokne="Invalid access token.";
messages.posted_on_all="Posted on all liked pages.";
messages.invalid_url='Entered URL is not valid.';
messages.invalid_delay='Delay time is invalid.';
