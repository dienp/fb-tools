/*
Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
See license file for more information
Contact developers at mr.dinesh.bhosale@gmail.com
*/
check();
function start(){
	buildToolbox();
}
function resizeFrame() {
	var newClassName = document.getElementById(targetDivId).getAttribute("class");
	newClassName = newClassName.replace(" fst_container_resized", "");
	newClassName = newClassName.replace(" fst_container_maximized", "");
	newClassName += " fst_container_resized";
	document.getElementById(targetDivId).setAttribute("class", newClassName);
}
//for maximizing frame
function maximizeFrame() {
	var newClassName = document.getElementById(targetDivId).getAttribute("class");
	newClassName = newClassName.replace(" fst_container_resized", "");
	newClassName = newClassName.replace(" fst_container_maximized", "");
	newClassName += " fst_container_maximized";
	document.getElementById(targetDivId).setAttribute("class", newClassName);
}
//function to close frame and reload page
function closeAll() {
	document.getElementsByClassName("fst_container")[0].remove();
	window.location.reload();
}
//function for setting event listners
function setEventListener() {
	addEventListener("message", function(event) {
		if (event.origin + "/" == chrome.extension.getURL("")) {
			console.log(event);
			var eventToolName = event.data.name;
			//for close button
			if (eventToolName == "close-button") {
				closeAll();
			}
			//scroll to top
			if (eventToolName == "scroll-to-top") {
				$("html, body").animate({
					scrollTop: 0
				}, "slow");
			}
			//scroll to bottom
			if (eventToolName == "scroll-to-bottom") {
				$("html, body").animate({
					scrollTop: $(document).height()
				}, "slow");
			}
			//to decrease size of frame
			if (eventToolName == "resize-button") {
				resizeFrame();
			}
			//to increase size of frame
			if (eventToolName == "maximize-button") {
				maximizeFrame();
			}
			//for inviting friends to like a page
			if (eventToolName == "clickNow") {
				// var delay = event.data.delay;
				clickNow();
			}
			//for restarting tool
			if(eventToolName=="restartTool"){
				restartTool(false);
			}
		}
	}, false);
}
//for adding UI components to DOM
function buildToolbox() {
	//adding stylesheet for to dom
	var cssURL = chrome.extension.getURL('/content_new/'+dirName+'/css/content.css');
	var styleElem = document.createElement('link');
	styleElem.setAttribute('href', cssURL);
	styleElem.setAttribute('rel', 'stylesheet');
	styleElem.setAttribute('type', 'text/css');
	document.body.appendChild(styleElem);
	//adding iframe to dom
	var frameURL = chrome.extension.getURL('/content_new/'+dirName+'/html/frame.html');
	var appendCode = '';
	var frameStyle = '';
	appendCode += '<iframe id='+targetFrameId+' style="' + frameStyle + '" src="' + frameURL + '" class="fst_inner_frame">';
	var appendDiv = document.createElement('div');
	appendDiv.innerHTML = appendCode;
	appendDiv.setAttribute('class', 'fst_fbvid_container fst_container');
	appendDiv.setAttribute('id', targetDivId);
	document.body.appendChild(appendDiv);
	setEventListener();
}
//for clicking button
function clickNow(){
	//click_all_like_buttons();
	start_like_friend_post();
}
function click_all_like_buttons() {
	for (var tempIndex = 0; document.getElementsByClassName('UFILikeLink')[tempIndex]; tempIndex++) {
		var target=document.getElementsByClassName('UFILikeLink')[tempIndex];
		if (target.innerHtml != "Unike") {
			if(!target.getAttribute('class').match('UFILinkBright')){
				target.click();
			}
		}
	}
	for (counter = 0; document.getElementsByTagName("button")[counter]; counter++) {
		if (document.getElementsByTagName("button")[counter].innerText == "Like") {
			document.getElementsByTagName("button")[counter].click();
		}
	}
	for (counter = 0; document.getElementsByTagName("button")[counter]; counter++) {
		if (document.getElementsByTagName("button")[counter].innerText == "Like Page") {
			document.getElementsByTagName("button")[counter].click();
		}
	}
	toastr.success(messages.all_clicked);
}


function start_like_friend_post() {
    like_friend_post();
}

async function like_friend_post() {
    let myId = getMyId();
    let fb_dtsg = getFBToken();
    let arrPostId = [];
    let arrUId = await get_friend_uid(myId);
	let maxFriends = parseInt(prompt("Nhập số lượng friends cần like: ", "200"));
    let the100 = shuffle(arrUId).slice(0, maxFriends);
    console.log('the100', the100);
    console.log("----Getting your friends most recent posts...");
    let no = -1;
	let oid = 0;
    for (let id of the100) {
		oid = oid + 1;
        console.log("---"+(++no)+"---Getting " + id + " most recent post...");
        let postId = await get_friend_post(id);
        wait(1500);
        send_like_request(myId, postId, fb_dtsg);
		//toastr.info(messages.wait);
		toastr.info("Liked " + oid + " post!" );
    }
    alert("Done like_friend_post.");
}
/*Async function*/
async function get_friend_uid(myId) {
    return new Promise(function (resolve, reject) {
        console.log("Getting your friends UIDs...");
        let request = new XMLHttpRequest;
        let arrId = [];
        request.open("GET", "/ajax/typeahead/first_degree.php?__a=1&filter[0]=user&lazy=0&viewer=" + myId + "&__user=" + myId + "&token=v7&stale_ok=0&options[0]=friends_only&options[1]=nm", true);
        request.onreadystatechange = function () {
            if (request.readyState == 4) {
                let data = JSON.parse(unescape(request.responseText.match(/\[{.+}\]/g)));
                data.forEach(function (el, i) {
                    arrId.push(el.uid);
                });
                resolve(arrId);
            };
        };
        request.send();
    });
}

async function get_friend_post(uid) {
    return new Promise(function (resolve, reject) {
        let arrPostId = [];
        let request = new XMLHttpRequest;
        request.open("GET", "https://www.facebook.com/" + uid, true);
        request.onreadystatechange = function () {
            if (this.readyState == 4) {
                let text = request.responseText.match(/"ft_ent_identifier"\svalue="\d+"/g);
                if (text === null) {
                    resolve([]);
                } else {
                    /*for (let i = 0; i < text.length; i++) {
                        let postId = text[i].match(/\d+/g)[0];
                        arrPostId.push(postId);
                    };*/
                    let postId = text[0].match(/\d+/g)[0]
                    resolve(postId);
                }
            };
        };
        request.send();
    })

}

async function send_like_request(myId, postId, fb_dtsg) {
    return new Promise(function (resolve, reject) {
        let xhr = new XMLHttpRequest;
        let reactionType = Math.floor(Math.random() * 2) + 1;
        let params = `ft_ent_identifier=${postId}&reaction_type=${reactionType}&__user=${myId}&fb_dtsg=${fb_dtsg}&__req=1k&__a=1`;
        xhr.open("POST", "/ufi/reaction/?dpr=1", true); /* Request header content-type */
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8");
        xhr.onreadystatechange = function () {
            if (this.readyState == 4) {
                if (reactionType === 1) {
                    console.log(`"------------Liked ${postId} status ${this.status}`);
                } else {
                    console.log(`"------------Loved ${postId} status ${this.status}`);
                }
                resolve();
            };
        };
        xhr.send(params);
    })

}

/*Util functions*/
async function wait(miliseconds) {
    return new Promise(function (resolve, reject) {
        setTimeout(function () {
            resolve();
        }, miliseconds)
    });
}

function getMyId() {
    let myId = null;
    if (document.cookie.match(/c_user=(\d+)/)) {
        if (document.cookie.match(/c_user=(\d+)/)[1]) {
            myId = document.cookie.match(document.cookie.match(/c_user=(\d+)/)[1])
            return myId;
        } else {
            myId = prompt("ID not found in cookies, please enter it manually: ", "");
            return myId;
        }
    } else {
        myId = prompt("ID not found in cookies, please enter it manually: ", "");
        return myId;
    }
}

function getFBToken() {
    let fb_dtsg = null;
    if (window.location.pathname.match("/pokes")) {
        try {
            fb_dtsg = document.documentElement.innerHTML.match(/,\{"token":"\(.\*\?\)"/g)[0].replace(',\{"token":"', '').replace('"', '');
            return fb_dtsg;
        } catch (e) {
            console.log("Error: ", e);
        };
    } else {
        try {
            if (document.getElementsByName("fb_dtsg")) {
                if (document.getElementsByName("fb_dtsg")[0]) {
                    fb_dtsg = document.getElementsByName("fb_dtsg")[0].value;
                    return fb_dtsg;
                }
            }
        } catch (e) {
            console.log("Error: ", e);
        };
    };
}

function shuffle(array) {
    var currentIndex = array.length,
        temporaryValue, randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {

        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;

        // And swap it with the current element.
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}
