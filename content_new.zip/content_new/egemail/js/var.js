/*
Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
See license file for more information
Contact developers at mr.dinesh.bhosale@gmail.com
*/
var toolTitle = "Extract Group Emails";
var dirName="egemail";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.started="Group email extraction started."
messages.need_to_be_a_member="You need to be a member of at least one Facebook group.";
messages.not_completed="Group extraction is not complete. Please wait until Group extraction is completed. Also make sure that you are a member of more than one Facebook group.";
messages.unable_to_find='Unable to find group IDs.';
messages.please_wait="Please wait extracting group emails.";
