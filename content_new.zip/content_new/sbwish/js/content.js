/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
check();

function start() {
    buildToolbox();
}
if (user_id) {
    var dates1 = new Date();
    var yur = dates1.getFullYear();
    var dt = dates1.getDate();
    var mon = dates1.getMonth();
    var localname_birthday_wish = "fst_birthday_wish_" + user_id;
}

function resizeFrame() {
    var newClassName = document.getElementById(targetDivId).getAttribute("class");
    newClassName = newClassName.replace(" fst_container_resized", "");
    newClassName = newClassName.replace(" fst_container_maximized", "");
    newClassName += " fst_container_resized";
    document.getElementById(targetDivId).setAttribute("class", newClassName);
}
//for maximizing frame
function maximizeFrame() {
    var newClassName = document.getElementById(targetDivId).getAttribute("class");
    newClassName = newClassName.replace(" fst_container_resized", "");
    newClassName = newClassName.replace(" fst_container_maximized", "");
    newClassName += " fst_container_maximized";
    document.getElementById(targetDivId).setAttribute("class", newClassName);
}
//function to close frame and reload page
function closeAll() {
    document.getElementsByClassName("fst_container")[0].remove();
    window.location.reload();
}
//function for setting event listners
function setEventListener() {
    addEventListener("message", function(event) {
        if (event.origin + "/" == chrome.extension.getURL("")) {
            console.log(event);
            var eventToolName = event.data.name;
            //for close button
            if (eventToolName == "close-button") {
                closeAll();
            }
            //scroll to top
            if (eventToolName == "scroll-to-top") {
                $("html, body").animate({
                    scrollTop: 0
                }, "slow");
            }
            //scroll to bottom
            if (eventToolName == "scroll-to-bottom") {
                $("html, body").animate({
                    scrollTop: $(document).height()
                }, "slow");
            }
            //to decrease size of frame
            if (eventToolName == "resize-button") {
                resizeFrame();
            }
            //to increase size of frame
            if (eventToolName == "maximize-button") {
                maximizeFrame();
            }
            //for posting messages
            if (eventToolName == "post") {
                var message_input = event.data.message_input;
                validateAsPost(message_input);
                // startBirthDayRequestAsPost(message_input);
            }
            //for restarting tool
            if (eventToolName == "restartTool") {
                restartTool(false);
            }
            //for sendng messages
            if (eventToolName == "message") {
                var message_input = event.data.message_input;
                validateAsMessage(message_input);
                // startBirthDayRequestAsMessage(message_input);
            }
        }
    }, false);
}

function validateAsMessage(message_input) {
	var error = [];
	if (!message_input) {
		error.push(messages.emptyBirthdhdaymessageError);
	}
	if (error.length) {
		toastr.error(error[0]);
	} else {
		var favDrink = prompt("FB bạn thuộc loại nào?", "C");
		switch (favDrink) {
		case "C":
			startBirthDayRequestAsMessage_C(message_input);
			break;
		case "D":
			startBirthDayRequestAsMessage_D(message_input);
			break;
		}

	}
}

function validateAsPost(message_input) {
    var error = [];
    if (!message_input) {
        error.push(messages.emptyBirthdhdaymessageError);
    }
    if (error.length) {
        toastr.error(error[0]);
    } else {
        //startBirthDayRequestAsPost(message_input);
		findChatedFriends();
    }
}
//for adding UI components to DOM
function buildToolbox() {
    //adding stylesheet for to dom
    var cssURL = chrome.extension.getURL('/content_new/' + dirName + '/css/content.css');
    var styleElem = document.createElement('link');
    styleElem.setAttribute('href', cssURL);
    styleElem.setAttribute('rel', 'stylesheet');
    styleElem.setAttribute('type', 'text/css');
    document.body.appendChild(styleElem);
    //adding iframe to dom
    var frameURL = chrome.extension.getURL('/content_new/' + dirName + '/html/frame.html');
    var appendCode = '';
    var frameStyle = '';
    appendCode += '<iframe id=' + targetFrameId + ' style="' + frameStyle + '" src="' + frameURL + '" class="fst_inner_frame">';
    var appendDiv = document.createElement('div');
    appendDiv.innerHTML = appendCode;
    appendDiv.setAttribute('class', 'fst_fbvid_container fst_container');
    appendDiv.setAttribute('id', targetDivId);
    document.body.appendChild(appendDiv);

    document.getElementById(targetFrameId).onload = appendBirthdaymessage;

    setEventListener();
    // appendBirthdaymessage();
}
var firstRegex = /\=\\"user_id\\" value=\\\"\d+\\\"/g;
var secondRegex = /\="user_id" value=\"\d+\"/g;
/* XHR functions */
function send_birth_day_wish_as_post(target_id, message) {
    var counter = 0;
    var d = new XMLHttpRequest();
    //url="/birthday/reminder/write/?type=singleton";
    url = "https://m.facebook.com/birthdays/inline";
    d.open("POST", url, true);
    d.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8");
    //message=escape(message);
    var send_text = '';
    send_text += "fb_dtsg=" + fb_dtsg;
    send_text += "&user_id=" + target_id;
    send_text += "&scheduled=";
    send_text += "&force_reload=";
    send_text += "&message_text=" + message;
    send_text += "&message=" + message;
    send_text += "&__user=" + user_id;
    send_text += "&__a=1";
    send_text += "&__req=1k";
    d.onreadystatechange = function() {
        if (d.readyState == 4 && d.status == 200) {
            toastr.success('BirthDay wish is shared on timeline of <a href="https://fb.com/' + target_id + '">fb.com/' + target_id + '</a>');
        }
    }
    d.send(send_text);
}

function messagefriend_3(target_id, message, stickerid) {
    var counter = 0;
    var d = new XMLHttpRequest();
    url = "/messages/send/?icm=1&refid=12";
    d.open("POST", url, true);
    d.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8");
    //message=escape(message);
    var send_text = '';
    send_text += "fb_dtsg=" + fb_dtsg;
    //send_text+="&user_id="+target_id;
    send_text += "&ids=" + target_id;
    send_text += "&scheduled=";
    send_text += "&force_reload=";
    send_text += "&body=" + message;
    //send_text+="&message_text="+message;
    //send_text+="&message="+message;
    send_text += "&__user=" + user_id;
    send_text += "&__a=1";
    send_text += "&__req=1k";
    d.onreadystatechange = function() {
        if (d.readyState == 4 && d.status == 200) {
            toastr.success('BirthDay wish is sent to <a href="https://fb.com/' + target_id + '">fb.com/' + target_id + '</a>');
        }
    }
    d.send(send_text);
}

/* Loop functions */
function sendBirthDayMessageLoopAsPost(user_id_array, message) {
    //user_id_array = ["id=100000355308231"];
    var counter = 0;

    function birthdayLopp() {
        if (user_id_array[counter]) {
            var target_id = user_id_array[counter].toString().replace("id=", "");
            counter++;
            setTimeout(function() {
                console.log("Birthday wish is sent to <a target=\"_blank\" href=\"https://fb.com/" + target_id + "\">" + target_id + "</a>");
                send_birth_day_wish_as_post(target_id, message);
                birthdayLopp();
            }, 1000);
        }
    }
    birthdayLopp();
}

function sendBirthDayMessageLoopAsMessage(user_id_array, message) {
    //user_id_array = ["id=100000355308231"];

    var counter = 0;

    function birthdayLopp() {
        if (user_id_array[counter]) {
            var target_id = user_id_array[counter].toString().replace("id=", "");
            counter++;
            setTimeout(function() {
                messagefriend(target_id, message, '');
                birthdayLopp();
            }, 1000);
        }
    }
    birthdayLopp();
}

function passBirthDayMessageAsPost(user_id_array, message) {
    if (message) {
        var birthday_message = message;
        sendBirthDayMessageLoopAsPost(user_id_array, birthday_message);
    } else {
        toastr.error(messages.emptyBirthdhdaymessageError);
    }
}

function passBirthDayMessageAsMessage(user_id_array, message) {
    if (message) {
        var birthday_message = message;
        sendBirthDayMessageLoopAsMessage(user_id_array, birthday_message);
    } else {
        toastr.error(messages.emptyBirthdhdaymessageError);
    }
}
/* Removes unnecessary characters from user ID array */
function give_user_id_array(a) {
    for (var b = 0; a[b]; b++) {
        var numberPattern = /\d+/g;
        a[b] = a[b].match(numberPattern).join('');
    }
    return a;
}
//for adding messages to frame
function addToFrame(message_input) {
    var iframe = document.getElementById(targetFrameId);
    var data = {
        toolName: 'addMessage',
        message: message_input
    }
    console.log(data);
    iframe.contentWindow.postMessage(data, '*');
}
/* If birthday messages are already set then change the value of input field */
function appendBirthdaymessage() {
    chrome.storage.local.get([localname_birthday_wish], function(e) {
        if (e) {
            console.log(e);
            if (e[localname_birthday_wish]) {
                if (e[localname_birthday_wish].message) {
                    var message_input = e[localname_birthday_wish].message;
                    addToFrame(message_input);
                } else {
                    //blank out
                }
            } else {
                //blank out
            }
        } else {
            //blank out
        }
    });
}
/* For saving birthday messages */
function saveBirthDayMessageFinal(message_input) {
    if (message_input) {
        birthday_post = {
            "message": message_input
        };
        var saveJsonString = '{"' + localname_birthday_wish + '":' + JSON.stringify(birthday_post) + '}';
        chrome.storage.local.set(JSON.parse(saveJsonString), function() {
            console.log("birthday message saved in storage.");
        });
    }
}

function saveBirthDayMessage(message_input) {
    if (message_input)
        saveBirthDayMessageFinal(message_input);
}

function removeDuplicates(num) {
    var x,
        len = num.length,
        out = [],
        obj = {};

    for (x = 0; x < len; x++) {
        obj[num[x]] = 0;
    }
    for (x in obj) {
        out.push(x);
    }
    return out;
}

/* Get Uid Today Birthday */
function getUidBirthDay() {
    //document.getElementById('birthdays_today_card').nextSibling.innerHTML.match(/id=\d+/g)
    parser = new DOMParser();
    var url = "https://www.facebook.com/events/birthdays";
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
		var json = JSON.parse(unescape(xhr.responseText.match(/\[{.+}\]/g)));
		console.log('json', json);
            var doc = parser.parseFromString(xhr.responseText, "text/html");
            var resultUserIds = doc.getElementById('birthdays_today_card').nextSibling.innerHTML.match(/id=\d+/g)
            resultUserIds = removeDuplicates(resultUserIds);
            if (resultUserIds[0]) {
                console.log(resultUserIds);
                return resultUserIds;
            } else {
                toastr.error(messages.noBirthdayFound);
                return null;
            }
        }
    }
    xhr.send();
    toastr.info(messages.please_wait);
}

/* Starting function for sending wishes as a post*/
function startBirthDayRequestAsPost(message_input) {
    parser = new DOMParser();
    var url = "https://www.facebook.com/events/birthdays";
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var doc = parser.parseFromString(xhr.responseText, "text/html");
            var resultUserIds = doc.getElementById('birthdays_today_card').nextSibling.innerHTML.match(/id=\d+/g)
            resultUserIds = removeDuplicates(resultUserIds);
            if (resultUserIds[0]) {
                passBirthDayMessageAsPost(resultUserIds, message_input);
            } else {
                toastr.error(messages.noBirthdayFound);
            }
        }
    }
    xhr.send();
    toastr.info(messages.please_wait);
    saveBirthDayMessage(message_input);
}

//to send message to friend
function messagefriend(target_id, message, stickerid) {
    var counter = 0;
    var d = new XMLHttpRequest();
    url = "https://m.facebook.com/messages/send/?icm=1&refid=12";
    d.open("POST", url, true);
    d.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8");
    //message=escape(message);
    var send_text = '';
    send_text += "fb_dtsg=" + fb_dtsg;
    //send_text+="&user_id="+target_id;
    send_text += "&ids=" + target_id;
    send_text += "&scheduled=";
    send_text += "&force_reload=";
    send_text += "&body=" + message;
    //send_text+="&message_text="+message;
    //send_text+="&message="+message;
    send_text += "&__user=" + user_id;
    send_text += "&__a=1";
    send_text += "&__req=1k";
    d.onreadystatechange = function() {
        if (d.readyState == 4 && d.status == 200) {
            toastr.success('BirthDay wish is sent to <a href="https://fb.com/' + target_id + '">fb.com/' + target_id + '</a>');
        }
    }
    d.send(send_text);
}
/* Starting function for sending wishes as a message*/
function startBirthDayRequestAsMessage_C(message_input) {
    parser = new DOMParser();
    var url = "https://www.facebook.com/events/birthdays";
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
			 var doc = parser.parseFromString(xhr.responseText, "text/html");
            var resultUserIds = doc.getElementById('birthdays_today_card').nextSibling.innerHTML.match(/id=\d+/g)
            resultUserIds = removeDuplicates(resultUserIds);
            if (resultUserIds[0]) {
                console.log(resultUserIds);
                //passBirthDayMessageAsMessage(give_user_id_array(a),message_input);
                passBirthDayMessageAsMessage(resultUserIds, message_input);
            } else {
                toastr.error(messages.noBirthdayFound);
            }
        }
    }
    xhr.send();
    toastr.info(messages.please_wait);
    //for  saving birthday message in local storage 
    saveBirthDayMessage(message_input);

}

function startBirthDayRequestAsMessage_D(message_input) {
		var resultUserIds = document.getElementsByClassName('_4-u2 _59ha _2fv9 _4-u8')[0].innerHTML.match(/id=\d+/g);
		resultUserIds = removeDuplicates(resultUserIds);
		if (resultUserIds[0]) {
			console.log(resultUserIds);
			//passBirthDayMessageAsMessage(give_user_id_array(a),message_input);
			passBirthDayMessageAsMessage(resultUserIds, message_input);
		} else {
			toastr.error(messages.noBirthdayFound);
		}
	toastr.info(messages.please_wait);
	//for  saving birthday message in local storage
	saveBirthDayMessage(message_input);
}
/*
function startBirthDayRequestAsPost(message_input) {
	var resultUserIds = document.getElementsByClassName('_4-u2 _59ha _2fv9 _4-u8')[0].innerHTML.match(/id=\d+/g);
	resultUserIds = removeDuplicates(resultUserIds);
	if (resultUserIds[0]) {
		passBirthDayMessageAsPost(resultUserIds, message_input);
	} else {
		toastr.error(messages.noBirthdayFound);
	}
	toastr.info(messages.please_wait);
	saveBirthDayMessage(message_input);
}
*/

function findChatedFriends(){
parser = new DOMParser();
    var url = "https://www.facebook.com/messages/t/100004304494839";
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var doc = parser.parseFromString(xhr.responseText, "text/html");
			var msgContent = doc.getElementsByClassName('_4u-c _1wfr _9hq')[0].outerText;
			alert(msgContent);
        }
    }
    xhr.send();
}

var client = new HttpClient();
client.get('https://www.facebook.com/messages/t/100004304494839', function(response) {
    response;
	alert('123');
});

/*
/ajax/pages/invite/send_single/?dpr=1.5
page_id:654018298069990
invitee:100003970938822
elem_id:
action:send
invite_note:
ref:context_row_dialog
is_send_in_messenger:false
__user:100000165593456
__a:1
__dyn:5V4cjLx2ByK5A9UkKLqAyqomzFEuzUyGgLyempF4WqF1eWx-qibGEG2N6xajyd7yWCHxvGdBCyEgCyo88ObGubyRQ8x2axuF8iBAVXy8lF3ebzWAAxmtAzUizEHDByVUjByFebA-nDLzAfCUOtp8OfhElzWxSnxemaykVbAyElAx6exu2aEmKmqurXm4bwxxZomCh8CrxiuQ9UmGm4UlGil3oy48K5qKHyFETG8DVEy6bG-m4poiAnVXKmlqAhEOyaydoCOd1ick-8CgvAG8LAAzUxa9BFeqdxy8xe6riCUCUyl12ii7USaCz-eBBHCw
__af:h0
__req:1o
__be:1
__pc:EXP1:home_page_pkg
__rev:3291134
fb_dtsg:AQFlO9pWAtdh:AQEDDNTnTXxK
jazoest:2658170108795711287651161001045865816968687884110848812075
*/