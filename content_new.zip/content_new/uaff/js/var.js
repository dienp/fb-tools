/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var dirName="uaff";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.incorrect_answer="Incorrect answer.";
messages.not_complete="Friend list extraction is not complete, Please wait until friend list extraction is complete. Also make sure that you have at least one Facebook friend.";
messages.confirm_msg="All friends will be unfollowed. Do you really want to do this? ";
messages.confirm_msg_1="Again confirm that you want to unfollow all friends.";
messages.confirm_msg_2="Are you sure you want to unfollow all friends from your friend list once it is done it can not be undone.";
messages.success_msg="All friends are unfollowed.";
